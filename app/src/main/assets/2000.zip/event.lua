local initFlag = true
local maleOpacity   = 1.0
local femaleOpacity = 0.0

EventHandles =
{
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        local feature = this:getFeature("FaceMakeupV2_byTool")
        local _feature = EffectSdk.castFaceMakeupV2Feature(feature)
        if (not feature) or (not _feature) then
            print("FaceMakeupV2_byTool is not exist")
            return false
        end
        
        if tag == "Internal_Makeup" then
            _feature:setIntensity("lips_keypoint_faceu+2994",percentage)
        -- elseif tag == "Internal_Makeup_Facial" then
            _feature:setIntensity("mask_faceuv2+2999",percentage)
        end
    end,

    handleGenderEvent = function(this, genderInfo)
        local feature = this:getFeature("FaceMakeupV2_byTool")
        local _feature = EffectSdk.castFaceMakeupV2Feature(feature)
        if (not feature) or (not _feature) then
            print("FaceMakeupV2_byTool is not exist")
            return false
        end

        local effect_manager      = this:getEffectManager()
        local isMaleMakeupOpen    = effect_manager:getMaleMakeupState()
        local _maleOpacity        = maleOpacity
        if not isMaleMakeupOpen then
            _maleOpacity = femaleOpacity
        end


        local vals = EffectSdk.vectorf()
        for i = 0,4 do
            if genderInfo:isMan(i) > 0.6 then
                vals:push_back(_maleOpacity)
            elseif genderInfo:isMan(i) < 0.4 then
                vals:push_back(femaleOpacity)
            else
                vals:push_back(femaleOpacity)
            end
        end
        _feature:setOpacity("lips_keypoint_faceu+2994",vals)
        _feature:setOpacity("mask_faceuv2+2999",vals)
    end,
}
