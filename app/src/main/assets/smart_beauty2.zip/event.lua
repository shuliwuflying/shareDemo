local CommonFunc = { 
    setFeatureEnabled = function (this, path, status)
        local feature = this:getFeature(path)
        if (feature) then
            feature:setFeatureStatus(EffectSdk.BEF_FEATURE_STATUS_ENABLED, status)
        end
    end,
    } 
local Sticker3DV3FaceU = { 
playClip = function (this, path, entityName, clipName, playTimes)
    local image2DManager = this:getImage2DManager()
    if (image2DManager) then
        image2DManager:reset(entityName, clipName)
        image2DManager:play(entityName, clipName, playTimes)
    end
end,

stopClip = function (this, path, entityName, clipName)
    local image2DManager = this:getImage2DManager()
    if (image2DManager) then
        image2DManager:resume(entityName, clipName, false)
        image2DManager:appear(entityName, clipName, false)
    end
end,
} 
local init_state = 1
local startTimerId = 9006
local feature_0 = {
folder = "ES3DV3Sprite9e085d3ecb9b4ffaab214254c24416b4",
clip = { "ProcessorName_1", "ProcessorName_0" }, 
entity = { "scene3d_4572310a995a4e3792e4433562353bfb" }, 
}
local feature_1 = {
folder = "3DStickerV3_5100",
}

local isStart = false 



EventHandles = {
    handleEffectEvent = function (this, eventCode)
        if (init_state == 1 and eventCode == 1) then
            init_state = 0
            Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1], 0)
            Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2], 0)
          CommonFunc.setFeatureEnabled(this, feature_1.folder, false)
            CommonFunc.setFeatureEnabled(this, feature_1.folder, true)
            local image2DManager = this:getImage2DManager()
            if (image2DManager) then
                image2DManager:play("dog_sfg_a01", "processorName01", 0)
            end
            -- this:addTimer(startTimerId, EffectSdk.BEF_TIMER_EVENT_ONCE, 2000)
            -- Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1], 2)
            -- Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2], 2)

        end
        return true
    end,
    handleRecodeVedioEvent = function (this, eventCode)
        if (eventCode == 1) then
            -- Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1])
            -- Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1], 0)
            -- Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2])
            -- Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2], 0)
        end
        return true
    end,

    handleClientMsgEvent = function (this, msgID, arg1, arg2, arg3)
        if msgID == 24  then
           -- EffectSdk.LOG_LEVEL(6, "接受到消息ID:24".."参数1"..arg1)
           if arg1 == 0 then 
                EffectSdk.LOG_LEVEL(6, "接受到消息ID:24,开始扫描。。。。")
                CommonFunc.setFeatureEnabled(this, feature_1.folder, true)
                local image2DManager = this:getImage2DManager()
                if (image2DManager) then
                    image2DManager:play("dog_sfg_a01", "processorName01", 0)
                end
                isStart = true 
           end 

           if arg1 == 1 then 
                EffectSdk.LOG_LEVEL(6, "接受到消息ID:24,扫描成功。。。。")
                -- 关闭3d美妆扫描效果
                CommonFunc.setFeatureEnabled(this, feature_1.folder, false)
                -- 播放序列帧动画
                Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1], 2)
                Sticker3DV3FaceU.playClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2], 2)
           end 

           if arg2 == 2 then 
                EffectSdk.LOG_LEVEL(6, "接受到消息ID:24,扫描失败。。。。")
                Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[1], 0)
                Sticker3DV3FaceU.stopClip(this, feature_0.folder, feature_0.entity[1], feature_0.clip[2], 0)
                CommonFunc.setFeatureEnabled(this, feature_1.folder, false)
           end 
        end
    end,

    }

