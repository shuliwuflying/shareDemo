local featurePath = "GESticker_Whiten"
EventHandles =
{
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        local feature_whiten = this:getFeature(featurePath)
        local ge_whiten = EffectSdk.castGeneralEffectFeature(feature_whiten) 
        if not ge_whiten then
            print("Error: whiten filter is nil!")
            return false
        end    
        if tag == "whitenIntensity" then
            local whitenIntensity = percentage
            ge_whiten:setUniformFloat("whiten", 1, "uniAlpha", whitenIntensity) 
            return true
        end
    end    
}
