local initFlag = true
local featurePath = "GESticker_Faceu_Beauty"
local ge = nil
local feature = nil
local globalTimerId = 3214349
local PI = 3.141592657
local ratio1 = 0.0
local useMask = 0
local quadVertexArray = {
    -1.0, -1.0, 0.0, 
     1.0, -1.0, 0.0, 
    -1.0, 1.0, 0.0, 
     1.0, 1.0, 0.0
}
local quadUvArray = {0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0}
local quadIndexArray = {0,1,2,1,3,2}
local target_degree = 0.58823
local needResetInputSize = false


local inputWidth = 720
local inputHeight = 1280

local lastInputWidth = 1
local lastInputHeight = 1

-- local function updateGEFeature(this)

--     inputWidth = this:getEffectManager():getInputWidth()
--     inputHeight = this:getEffectManager():getInputHeight()

--     if lastInputWidth ~= inputWidth or lastInputHeight  ~=  inputHeight then   
--         -- print("input resolution changed! input width: "..inputWidth.." input height: "..inputHeight)             
--         if ge == nil or feature == nil then
--             -- print("GeneralEffect feature is invalid!")
--             return
--         end
--         ge:setUniformVec2("face_mask", 1, "inputTextureSize", inputWidth,inputHeight);

--         lastInputWidth = inputWidth
--         lastInputHeight = inputHeight
--     end            
-- end

local function updateGEFeature(this)

    inputWidth = this:getEffectManager():getInputWidth()
    inputHeight = this:getEffectManager():getInputHeight()
    local isInputSizeChanged = false

    if lastInputWidth ~= inputWidth or lastInputHeight  ~=  inputHeight then   
        -- print("input resolution changed! input width: "..inputWidth.." input height: "..inputHeight)             
        if ge == nil or feature == nil then
            print("GeneralEffect feature is invalid!")
            return
        end
        -- 由于人脸算法是异步的，当前帧拿到的人脸算法结果实际上是上一帧的结果
        ge:setUniformVec2("face_mask", 1, "inputTextureSize", lastInputWidth,lastInputHeight);

        lastInputWidth = inputWidth
        lastInputHeight = inputHeight
        isInputSizeChanged = true
    end            
    -- 检测到输入图像变化后的第2帧，将inputSize更新
    if(needResetInputSize) then
        ge:setUniformVec2("face_mask", 1, "inputTextureSize", lastInputWidth,lastInputHeight);
        needResetInputSize = false
    end

    if(isInputSizeChanged) then
        needResetInputSize = true
    end         
end

local function setBrcData(this, generalEffec, effectName)

    local mode = 4
    local vertexStep = 3
    local uvStep = 2
    local vertexList = EffectSdk.vectorp3()
    local uvList = EffectSdk.vectorp3()
    local indexList = EffectSdk.vectori()

    -- get face data
    local effect_manager = this:getEffectManager()
    local facedata    = effect_manager:getBundleInfo()
    local maxFaceNum = 5

    --------------------------------------------------------
    -- test
    -- local faceInfo  = facedata:GetHandle("facedetect")
    -- if faceInfo ~= nil then
    --     local faceCnt = faceInfo.rawFaceInfo.face_count
    --     print("face count:"..faceCnt)
    -- else
    --     print("face info is empty!")
    -- end
    --------------------------------------------------------

    -- 单人时美妆网面顶点数
    local oneFaceMakeupMeshVertexNum = 248
    local vertexName =  "cv248points_"
    local uvName = "cv248uv_0"
    local indexName = "cv248index_"
    -- 获取美妆模特图的uv和绘制索引数据
    local uv_data  = facedata:GetFloatArray(uvName)
    local detectFaceCount = 0    
    for i = 0, maxFaceNum - 1 do
        local vertex_data   = facedata:GetFloatArray(vertexName..i)
        if(vertex_data ~= nil) then
            -- print("the data is here"..vertex_data[0]..","..uv_data[0])
            -- print(facedata)
            local vertexNum = vertex_data:size()
            -- 顶点数组
            for j = 0, vertexNum - 1, 2 do
                local pt = EffectSdk.Vec3(vertex_data[j], vertex_data[j+1], 0)
                vertexList:push_back(pt)
            end
            -- uv数组
            for j = 0, vertexNum - 1, 2 do
                local pt = EffectSdk.Vec3(uv_data[j], uv_data[j+1], 0)
                uvList:push_back(pt)
            end
            -- 索引数组
            local index_data = facedata:GetFloatArray(indexName..i) 
            local indexNum = index_data:size()
            for j = 0, indexNum - 1, 1 do
                indexList:push_back(index_data[j] + i * vertexNum/2)
            end                        
        else
            break
        end
        detectFaceCount = detectFaceCount + 1
    end
    -- 无人时
    if detectFaceCount == 0 then
        -- print("didn't detect any face.")
        useMask = 0
        for i = 1, #quadVertexArray, 3 do
            local pt = EffectSdk.Vec3(quadVertexArray[i], quadVertexArray[i+1], quadVertexArray[i+2])
            vertexList:push_back(pt)
        end
        for i = 1, #quadUvArray, 2 do
            local pt = EffectSdk.Vec3(quadUvArray[i], quadUvArray[i+1], 0)
            uvList:push_back(pt)
        end
        for i = 1, #quadIndexArray, 1 do
            indexList:push_back(quadIndexArray[i])
        end
    else
        -- print("detect "..detectFaceCount.." face.")
        useMask = 1
    end

    -- if detectFaceCount <= 0 and not isFrontCamera then
    --     needDisableSmoothSkin = true
    -- else
    --     needDisableSmoothSkin = false
    -- end

    generalEffec:setBrcData(effectName, mode, vertexList, vertexStep, uvList, uvStep, indexList)
end

EventHandles =
{
    handleFaceInfoEvent = function(this, faceInfo)
        if initFlag == true or ge == nil then
            return
        end
        -- local width = this:getEffectManager():getInputWidth()
        -- local height = this:getEffectManager():getInputHeight()
        -- ge:setUniformVec2("blend", 1, "resolution", width, height);
        -- ge:setUniformVec2("blend", 1, "resolution_inv", 1. / width, 1. / height);
        -- ratio = math.max(ratio1, 0.1)
        -- ratio1 = 1.0
        ge:setUniformFloat("blur1", 1, "ratio", ratio1);
        ge:setUniformFloat("blur2", 1, "ratio", ratio1);
        ge:setUniformFloat("face_mask", 1, "ratio", ratio1);
        ge:setUniformFloat("blend", 1, "ratio", ratio1);
        -- ge:setUniformFloat("blend", 1, "target_degree", target_degree);
        -- print("ratio ", ratio1, target_degree)
        
    end,
    handleEffectEvent = function (this, eventCode)
                            this:addTimer( globalTimerId, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 1)
                            if initFlag then
                                feature = this:getFeature(featurePath)
                                ge = EffectSdk.castGeneralEffectFeature(feature)
                                -- if ge ~= nil then
                                --     print("hahahahahaha")
                                -- end 
                                initFlag = false
                                -- print("init complete!")
                            end
                            return true
                        end,
    handleTimerEvent = function (this, timerId, milliSeconds)
        if timerId ~= globalTimerId or initFlag or ge == nil then
            return
        end
        updateGEFeature(this)
        setBrcData(this,ge, "face_mask")
    end,
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        if tag == "yaguang" then
            ratio1 = percentage
        end
        -- if tag == "yaguang_target_degree" then
        --     target_degree = percentage
        -- end
    end,

}
