local featurePath = "bgEffect_5104"

local scale = 1.0
local scale_coeff = 1.0

local renderWidth = 750
local renderHeight = 1334

local timerID = 1234
local a = 0

local face = false

EventHandles = {
    handleEffectEvent = function(this, eventCode)
        this:addTimer(timerID, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)
        local feature = this:getFeature(featurePath)
        renderWidth = feature:getDisplayWidth () * 1.0
        renderHeight = feature: getDisplayHeight () * 1.0
        if (renderWidth > 1200.0) then
            scale = renderWidth / 1080.0
            scale_coeff = (scale + 1.0) * 0.5
            stdDev_scale = 500.0
        else
            -- stdDev_scale = 1000.0
            scale = math.max(renderWidth / 720.0, 1.5)
            scale_coeff = (scale + 1.0) * 0.5
            stdDev_scale = 400.0 * (renderWidth / 4000.0)
        end
        local ge_blur = EffectSdk.castGeneralEffectFeature(feature)
        if not ge_blur then
            print("Error: whiten filter is nil!")
            return false
        end
        ge_blur:setUniformVec2("words", 1, "screenSize", renderWidth * 0.25, renderHeight * 0.25)
        ge_blur:setUniformFloat("words", 1, "scale", scale)
        ge_blur:setUniformFloat("words", 1, "radius", 2.0 * scale)
        ge_blur:setUniformFloat("words", 1, "stdDev", 0.406667 * stdDev_scale * 1.5 + 0.01)
        ge_blur:setUniformFloat("words", 1, "blurSize", 1.0 * scale_coeff)
    end,
    handleTimerEvent = function(this, timerId, milliSeconds)
        if (timerId == timerID) then
            local feature = this:getFeature(featurePath)
            renderWidth = feature:getDisplayWidth () * 1.0
            renderHeight = feature: getDisplayHeight () * 1.0
            if (renderWidth > 1200.0) then
                scale = renderWidth / 1080.0
                scale_coeff = (scale + 1.0) * 0.5
                stdDev_scale = 500.0
            else
                -- stdDev_scale = 1000.0
                scale = math.max(renderWidth / 720.0, 1.5)
                scale_coeff = (scale + 1.0) * 0.5
                stdDev_scale = 400.0 * (renderWidth / 4000.0)
            end
            local ge_blur = EffectSdk.castGeneralEffectFeature(feature)
            if not ge_blur then
                print("Error: whiten filter is nil!")
                return false
            end
            ge_blur:setUniformVec2("words", 1, "screenSize", renderWidth * 0.25, renderHeight * 0.25)
            ge_blur:setUniformFloat("words", 1, "scale", scale)
            ge_blur:setUniformFloat("words", 1, "radius", 2.0 * scale)
            ge_blur:setUniformFloat("words", 1, "stdDev", 0.406667 * stdDev_scale * 1.5 + 0.01)
            ge_blur:setUniformFloat("words", 1, "blurSize", 1.0 * scale_coeff)
        end
    end,

    handleTouchEvent = function (this, eventCode, screenPosX, screenPosY)
        local interface = this:getEffectManager()
        local effectManager = EffectSdk.castEffectManager(interface)
        local mattingData = effectManager:getVideoFrameAlgorithmResult("VideoFrame", "10")
        local mattingInfo = EffectSdk.autoCastBaseLuaObject(mattingData)
        local resultRect = mattingInfo:getResultRect()
        local useTouch = false
        if face == false or resultRect.bottom - resultRect.top < 0.01 or resultRect.right - resultRect.left < 0.01 then
            useTouch = true
        end
        if (eventCode == 1 and useTouch == true) then
            print("screen position : "..screenPosX.." ; "..screenPosY)
            local feature = this:getFeature(featurePath)
            local ge_blur = EffectSdk.castGeneralEffectFeature(feature)
            if not ge_blur then
                print("Error: whiten filter is nil!")
                return false
            end
            ge_blur:setUniformVec2("words", 1, "touchPoint", screenPosX, screenPosY)
        end
    end,
    
    handleComposerUpdateNodeEvent = function(this, path, tag, percentage)
        local feature_blur = this:getFeature(featurePath)
        local ge_blur = EffectSdk.castGeneralEffectFeature(feature_blur)
        if not ge_blur then
            print("Error: blur filter is nil!")
            return false
        end
        if tag == "blurIntensity" then
            local blurIntensity = percentage
            ge_blur:setUniformFloat("words", 1, "blurStrength", blurIntensity * 0.65)
            return true
        end
    end,

    handleFaceInfoEvent = function(this,faceInfo)
        faceCnt = faceInfo:getFaceCount()
        if (face == false and faceCnt > 0)then
            face = true
        end
        if (face == true and faceCnt == 0) then
            face = false
        end
    end
}
