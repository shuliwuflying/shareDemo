local exports = exports or {}
local TextControl = TextControl or {}
TextControl.__index = TextControl
function TextControl.new(construct, ...)
    local self = setmetatable({}, TextControl)
    return self
end
function TextControl:constructor()
end
function TextControl:onComponentAdded(sys, comp)
    if (comp:isInstanceOf("MeshRenderer")) then
        self.comp = comp
    end
end
function TextControl:onComponentRemoved(sys, comp) 
end
function TextControl:onStart(sys)
end
function TextControl:onUpdate(sys,deltaTime)
	if self.comp then
		self.comp.material:setFloat("u_scale", Amaz.BuiltinObject:getOutputTextureHeight() / 720.0)
	end
    
end
exports.TextControl = TextControl
return exports
