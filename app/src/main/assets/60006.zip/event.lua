local faceuFeaturePath = "distortionFaceu_test/"

-- keep EyeType in structure is for coordination with facepoint structure
local organName =
{
    "DISTORTION_V3_NEW_QINGYAN_FAR_EYE",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_EYE",
    "DISTORTION_V3_NEW_QINGYAN_ROTATE_EYE",
    "DISTORTION_V3_NEW_QINGYAN_MOVE_EYE",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_NOSE",
    "DISTORTION_V3_NEW_QINGYAN_MOVE_NOSE",
    "DISTORTION_V3_NEW_QINGYAN_MOVE_MOUTH",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_MOUTH",
    "DISTORTION_V3_NEW_QINGYAN_MOVE_CHIN",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_FOREHEAD",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_FACE",
    "DISTORTION_V3_NEW_QINGYAN_CUT_FACE",
    "DISTORTION_V3_NEW_QINGYAN_SMALL_FACE",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_JAW_BONE",
    "DISTORTION_V3_NEW_QINGYAN_ZOOM_CHEEK_BONE",
    "DISTORTION_V3_NEW_QINGYAN_DRAG_LIPS",
    "DISTORTION_V3_NEW_QINGYAN_CORNER_EYE",
    "DISTORTION_V3_NEW_QINGYAN_LIP_ENHANCE",
    "DISTORTION_V3_NEW_QINGYAN_POINTY_CHIN",
    "DISTORTION_V3_NEW_QINGYAN_TEMPLE",
    " ", -- eye type
    "DISTORTION_V3_NEW_QINGYAN_VFACE"
}

-- 22 items in organParam, [0,20] [22] 是小项，[21]是眼睛类型
-- 自然脸
local organParam =
{
 0.08,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
 -0.2,
    0,
-0.01,
    0,
    0,
    0,
    0,
    0,
    0,
 -0.2,
    2,
    0
}

-- 对齐轻颜
-- small item param range
local organParamRange =
{
    {-0.18,  0.18}, -- far eye
    {    0,  0.14}, -- zoom eye
    {    0,     0}, -- rotate eye
    {  0.2,  -0.2}, -- move eye
    {    0, -0.14}, -- zoom nose
    { 0.28, -0.28}, -- move nose
    { 0.36, -0.36}, -- move mouth
    { 0.12, -0.12}, -- zoom mouth
    { 0.14,  -0.2}, -- move chin
    {  0.2,  -0.2}, -- zoom forehead
    {    0,     0}, -- zoom face
    {    0,  -0.2}, -- cut face
    {    0, -0.07}, -- small face
    {    0,  -0.2}, -- jawbone
    {    0,  -0.2}, -- cheek bone
    {    0, -0.12}, -- mouth corner
    {    0,  -0.2}, -- corner eye
    {    0,     0}, -- lip enhance
    {  0.2,  -0.2}, -- pointy chin
    {    0,     0}, -- temple
    {    0,     0}, -- eye type
    {    0,  -1.4}, -- vface
}

local organParamPercentageInit =
{
      0.5, -- far eye
        0, -- zoom eye
        0, -- rotate eye
      0.5, -- move eye
        0, -- zoom nose
      0.5, -- move nose
      0.5, -- move mouth
      0.5, -- zoom mouth
0.4117647, -- move chin
      0.5, -- zoom forehead
        0, -- zoom face
        0, -- cut face
        0, -- small face
        0, -- jawbone
        0, -- cheek bone
        0, -- mouth corner
        0, -- corner eye
        0, -- lip enhance
      0.5, -- pointy chin
        0, -- temple
        0, -- eye type
        0, -- vface
}

-- -- 对齐工具
-- -- small item param range
-- local organParamRange =
-- {
--     { -0.2,   0.2}, -- far eye
--     {    0,  0.2}, -- zoom eye
--     {    0,     0}, -- rotate eye
--     {  0.2,  -0.2}, -- move eye
--     {    0,  -0.2}, -- zoom nose
--     {  0.2,  -0.2}, -- move nose
--     {  0.2,  -0.2}, -- move mouth
--     {  0.2,  -0.2}, -- zoom mouth
--     {  0.2,  -0.2}, -- move chin
--     {  0.2,  -0.2}, -- zoom forehead
--     {    0,     0}, -- zoom face
--     {    0,  -0.2}, -- cut face
--     {    0,  -0.2}, -- small face
--     {    0,  -0.2}, -- jawbone
--     {    0,  -0.2}, -- cheek bone
--     {    0,  -0.2}, -- mouth corner
--     {    0,  -0.2}, -- corner eye
--     {    0,     0}, -- lip enhance
--     {  0.2,  -0.2}, -- pointy chin
--     {    0,     0}, -- temple
--     {    0,     0}, -- eye type
--     {    0,    -2}, -- vface
-- }

-- local organParamPercentageInit =
-- {
--       0.5, -- far eye
--         0, -- zoom eye
--         0, -- rotate eye
--       0.5, -- move eye
--         0, -- zoom nose
--       0.5, -- move nose
--       0.5, -- move mouth
--       0.5, -- zoom mouth
--       0.5, -- move chin
--       0.5, -- zoom forehead
--         0, -- zoom face
--         0, -- cut face
--         0, -- small face
--         0, -- jawbone
--         0, -- cheek bone
--         0, -- mouth corner
--         0, -- corner eye
--         0, -- lip enhance
--       0.5, -- pointy chin
--         0, -- temple
--         0, -- eye type
--         0, -- vface
-- }

-- param range in engine
local organMaxInEigine =
{
        3, -- far eye, set default param max value to 3
      0.2, -- zoom eye
        3, -- rotate eye
      0.2, -- move eye
      0.2, -- zoom nose
     0.28, -- move nose
     0.36, -- move mouth
      0.2, -- zoom mouth
      0.2, -- move chin
      0.2, -- zoom forehead
        3, -- zoom face
      0.2, -- cut face
      0.2, -- small face
      0.2,-- jawbone
      0.2, -- cheek bone
      0.2, -- mouse corner
      0.2, -- corner eye
        3, --  lip enhance
      0.2, -- pointy chin
        3, -- temple
        3, -- eye type
        2, -- vface
}

local organParamSpecific = {}
local organParamCurrent = {}

local faceuInit = false

-- 确保获取的比例值是在[0,1]区间内
local function validatePercentage(percentage)
    if percentage < 0 then
        percentage = 0
    elseif percentage > 1 then
        percentage = 1
    end
    return percentage
end

-- 确保将要设置到引擎里面的参数在引擎允许值的范围内
local function validateParam(value, index)
    if value > organMaxInEigine[index] then
        value = organMaxInEigine[index]
    elseif value < -organMaxInEigine[index] then
        value = -organMaxInEigine[index]
    end
    return value
end

-- 获取每个小项在特定比例下调整后的具体参数
-- 注意正负非对称的情况，要特殊处理，比如 Internal_Deform_Chin，因为要确保滑竿0.5时没有形变效果
local function getSmallItemValueBy(percentage, index)
    if index == 9 then -- Internal_Deform_Chin
        if percentage < 0.5 then
            percentage = 1 - percentage * 2 -- [0, 0.5) -> [1, 0)
            return percentage * organParamRange[index][1]
        elseif percentage > 0.5 then
            percentage = percentage * 2 - 1 -- (0.5, 1] -> (0, 1]
            return percentage * organParamRange[index][2]
        else
            return 0
        end
    end
    percentage = validatePercentage(percentage)
    return organParamRange[index][1] + percentage * (organParamRange[index][2] - organParamRange[index][1])
end

-- 根据下标和比例设置小项值
local function setIntensityForSmallItem(feature, percentage, index)
    organParamSpecific[index] = getSmallItemValueBy(percentage, index)
    print("varName:","small item:",organParamSpecific[index],"base face:",organParamCurrent[index])
    local value = validateParam(organParamSpecific[index] + organParamCurrent[index], index)
    print("varName:", organName[index], "percentage:", percentage, "value:",value)
    feature:setIntensity(organName[index], value)
end

-- 获取基础脸型调整的具体参数
local function getBasicFaceValueBy(percentage, index)
    percentage = validatePercentage(percentage)
    return percentage * organParam[index]
end

-- 整体 调整基础脸型时设置每个小项的参数
local function setIntensityForBasicFace(feature, percentage, index)
    organParamCurrent[index] = getBasicFaceValueBy(percentage, index)
    local value = validateParam(organParamSpecific[index] + organParamCurrent[index], index)
    feature:setIntensity(organName[index], value)
end

-- 用滑杆的初始值来初始化小项的值
local function initAllSmallItem(feature)
    for i = 1,20 do
        setIntensityForSmallItem(feature, organParamPercentageInit[i], i);
    end
    setIntensityForSmallItem(feature, organParamPercentageInit[22], 22);
end

-- 初始化系统参数并使用滑杆初始值来初始化小项的值
local function initSystem(this)
    faceuInit = true
    local organParamCount = #organParam
    for i = 1, organParamCount do
        table.insert(organParamSpecific, i, 0)
        table.insert(organParamCurrent, i, 0)
        -- print("organParamCurrent", i, organParamCurrent[i])
    end

    local feature = this:getFeature(faceuFeaturePath)
    if not feature then
        print("dsFaceu feature nil")
        return
    end
    initAllSmallItem(feature)
end

EventHandles =
{
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        -- 和composer配合使用时，有可能handleComposerUpdateNodeEvent调用在handleEffectEvent之前，
        -- 所以这里要考虑初始化
        if not faceuInit then
            print("dsFaceu handleComposerUpdateNodeEvent init")
            initSystem(this)
        end

        print("dsFaceu handleComposerUpdateNodeEvent path = ", path, "\n")
        print("dsFaceu handleComposerUpdateNodeEvent tag = ", tag, "\n")
        print("dsFaceu handleComposerUpdateNodeEvent value = ", percentage, "\n")
        local feature = this:getFeature(faceuFeaturePath)
        if not feature then
            print("dsFaceu feature nil")
            return
        end

        --  整体
        if (tag == "Internal_Deform_Face") then
            for i = 1, 20 do
                setIntensityForBasicFace(feature, percentage, i);
            end
            setIntensityForBasicFace(feature, percentage, 22);
            return
        -- 眼间距
        elseif (tag == "Internal_Eye_Spacing") then
            setIntensityForSmallItem(feature, percentage, 1)
        -- 大眼
        elseif (tag == "Internal_Deform_Eye") then
            setIntensityForSmallItem(feature, percentage, 2)
        -- 眼上下
        elseif (tag == "Internal_Deform_MoveEye") then
            setIntensityForSmallItem(feature, percentage, 4)
        -- 瘦鼻
        elseif (tag == "Internal_Deform_Nose") then
            setIntensityForSmallItem(feature, percentage, 5)
         -- 长鼻
        elseif (tag == "Internal_Deform_MovNose") then
            setIntensityForSmallItem(feature, percentage, 6)
        -- 缩人中
        elseif (tag == "Internal_Deform_MovMouth") then
            setIntensityForSmallItem(feature, percentage, 7)
        -- 嘴型
        elseif (tag == "Internal_Deform_ZoomMouth") then
            setIntensityForSmallItem(feature, percentage, 8)
        -- 下巴
        elseif (tag == "Internal_Deform_Chin") then
            setIntensityForSmallItem(feature, percentage, 9)
        -- 额头/发际线
        elseif (tag == "Internal_Deform_Forehead") then
            setIntensityForSmallItem(feature, percentage, 10)
        -- 削脸/窄脸
        elseif (tag == "Internal_Deform_CutFace") then
            setIntensityForSmallItem(feature, percentage, 12)
        -- 小脸
        elseif tag == "Internal_Deform_SmallFace" then
            setIntensityForSmallItem(feature, percentage, 13)
        -- 瘦下颌骨
        elseif (tag == "Internal_Deform_Zoom_Jawbone") then
            setIntensityForSmallItem(feature, percentage, 14)
        -- 瘦颧骨
        elseif (tag == "Internal_Deform_Zoom_Cheekbone") then
            setIntensityForSmallItem(feature, percentage, 15)
        -- 微笑嘴角
        elseif (tag == "Internal_Deform_MouthCorner") then
            setIntensityForSmallItem(feature, percentage, 16)
        -- 开眼角
        elseif (tag == "Internal_Deform_CornerEye") then
            setIntensityForSmallItem(feature, percentage, 17)
        -- 尖下巴
        elseif (tag == "Internal_Deform_ChinSharp") then
        setIntensityForSmallItem(feature, percentage, 19)
        -- V 脸
        elseif (tag == "Internal_Deform_VFace") then
        setIntensityForSmallItem(feature, percentage, 22)
        end
        return true
    end,
    handleEffectEvent = function(this, eventCode)
        if not faceuInit then
            print("dsFaceu handleEffectEvent init")
            initSystem(this)
        end
        return true
    end,
}
